<!DOCTYPE html>
<html>
<head>
<title>Exercise 1 for CIT 313</title>
</head>
<body>