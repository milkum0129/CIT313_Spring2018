<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:21771/CIT313/SP2018/a4/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'mnastal');
define('DB_PASS', 'Milkyway12');
define('DB_NAME', 'mnastal_db');

define('REQFIELD', '<font color="#FF0000">*</font>');
?>