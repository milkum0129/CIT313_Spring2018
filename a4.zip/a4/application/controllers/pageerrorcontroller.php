<?php

class PageErrorController extends Controller
{
	public function index()
	{
	
	}
}
?>