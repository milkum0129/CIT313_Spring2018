<?php

echo $response;
?>