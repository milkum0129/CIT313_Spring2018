<!DOCTYPE html>
<html>
<head>
<title>Fisher Price - My First Model View Controller</title>
</head>
<body>
<h1>Hello From My View</h1>

<?php
echo "<ul>";
echo "<li>UserID: $userID</li>";
echo "<li>First Name: $firstname</li>";
echo "<li>Last Name: $lastname</li>";
echo "<li>Email: $email</li>";
echo "<li>Role: $role</li>";
echo "</ul>";
?>
</body>
</html>
